<?php
/**
* Copyright (c)2013 Card Gate Plus
* Author: Richard Schoots
* For more infomation about Card Gate Plus: http://www.cardgate.com 
* Released under the GNU General Public License
* Zen-Cart version Copyright (c) 2011 GetZenned: http://www.getzenned.nl
*/

  define('MODULE_PAYMENT_CGP_DIRECTDEBIT_TEXT_TITLE', 'Direct Debit');
  define('MODULE_PAYMENT_CGP_DIRECTDEBIT_TEXT_DESCRIPTION', 'Neem contact op met Card Gate Plus (www.cardgate.com) voor informatie');
  define('MODULE_PAYMENT_CGP_DIRECTDEBIT_CONFIRMATION_TITLE', '(Via Card Gate Plus)');
  define('MODULE_PAYMENT_CGP_DIRECTDEBIT_CONFIRMATION_TEXT', '');
  define('MODULE_PAYMENT_CGP_DIRECTDEBIT_TEXT_ERROR', 'Er is een fout opgetreden');
  define('MODULE_PAYMENT_CGP_DIRECTDEBIT_TEXT_ERROR_MESSAGE', 'Er is een fout opgetreden bij het verwerken van uw betaling. Probeert u het nogmaals.');

?>
