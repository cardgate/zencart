<?php
/**
* Copyright (c)2013 Card Gate Plus
* Author: Richard Schoots
* For more infomation about Card Gate Plus: http://www.cardgate.com 
* Released under the GNU General Public License
* Zen-Cart version Copyright (c) 2011 GetZenned: http://www.getzenned.nl
*/

  define('MODULE_PAYMENT_CGP_GIFTCARD_TEXT_TITLE', 'Gift Card');
  define('MODULE_PAYMENT_CGP_GIFTCARD_TEXT_DESCRIPTION', 'Contact Card Gate Plus (www.cardgate.com) for accounts');
  define('MODULE_PAYMENT_CGP_GIFTCARD_CONFIRMATION_TITLE', '(Via Card Gate Plus)');
  define('MODULE_PAYMENT_CGP_GIFTCARD_CONFIRMATION_TEXT', '');
  define('MODULE_PAYMENT_CGP_GIFTCARD_TEXT_ERROR', 'An error has occured');
  define('MODULE_PAYMENT_CGP_GIFTCARD_TEXT_ERROR_MESSAGE', 'There has been an error processing your payment. Please try again.');

?>
